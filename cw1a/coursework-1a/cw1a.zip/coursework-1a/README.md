# CW1a: x86lite simulator

Quick Start:

1. open the folder in VSCode (it will prompt you to "Reopen in dev container" -- do that)
2. start an OCaml sandbox terminal
3. run `make test` from the command line
4. open `bin/simulator.ml`

See the general toolchain and project instructions on the course web site. The
course web pages have a link to the html version of the homework instructions.

